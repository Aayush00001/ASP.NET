﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class bold_italic__backcolor_clear_image : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int currentSize = Convert.ToInt32(Label1.Font.Size.Unit.Value.ToString());
        Label1.Font.Size = currentSize + 1;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int currentSize = Convert.ToInt32(Label1.Font.Size.Unit.Value.ToString());
        Label1.Font.Size = currentSize - 1;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Label1.Font.Bold = !Label1.Font.Bold;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Label1.Font.Italic = !Label1.Font.Italic;
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        if (Label1.BackColor == System.Drawing.Color.Green)
        {
            Label1.BackColor = System.Drawing.Color.Empty;
        }
        else
        {
            Label1.BackColor = System.Drawing.Color.Green;
        }
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Label1.Font.Bold = false;
        Label1.Font.Italic = false;
        Label1.BackColor = System.Drawing.Color.Empty;
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton1.ImageUrl = null;
    }
    protected void  ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton1.ImageUrl = "~/images/65953d35ae7e4_download.jpg";
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton1.ImageUrl = "~/images/65953d514ec1f_download.jpg";
    }
}
