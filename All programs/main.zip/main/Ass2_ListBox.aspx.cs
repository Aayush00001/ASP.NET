﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ass2_ListBox : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        ListBox1.Items.Add(TextBox1.Text);
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        ListBox2.Items.Add(TextBox2.Text);
    }

    protected void Button7_Click(object sender, EventArgs e)
    {
        String[] arr = new string[10];
        int c = 0;
        for (int i = 0; i < ListBox1.Items.Count; i++)
        {
            if (ListBox1.Items[i].Selected)
            {
                arr[c] = ListBox1.Items[i].Value;
                BulletedList1.Items.Add(arr[c]);
                c++;
            }
        }
        for (int i = 0; i < c; i++)
        {
            ListBox1.Items.Remove(arr[i]);
        }
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        String[] arr = new string[10];
        int c = 0;
        for (int i = 0; i < ListBox2.Items.Count; i++)
        {
            if (ListBox2.Items[i].Selected)
            {
                arr[c] = ListBox2.Items[i].Value;
                BulletedList1.Items.Add(arr[c]);
                c++;
            }
        }
        for (int i = 0; i < c; i++)
        {
            ListBox2.Items.Remove(arr[i]);
        }
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        ListBox1.Items.Clear();
        ListBox2.Items.Clear();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        while (ListBox1.Items.Count != 0)
        {
            for (int i = 0; i < ListBox1.Items.Count; i++)
            {
                ListBox2.Items.Add(ListBox1.Items[i]);
                ListBox1.Items.Remove(ListBox1.Items[i]);
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        while (ListBox2.Items.Count != 0)
        {
            for (int i = 0; i < ListBox2.Items.Count; i++)
            {
                ListBox1.Items.Add(ListBox2.Items[i]);
                ListBox2.Items.Remove(ListBox2.Items[i]);
            }
        }
    }
   List<ListItem> arraylist1 = new List<ListItem>();
   List<ListItem> arraylist2 = new List<ListItem>();
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedIndex >= 0)
        {
            for (int i = 0; i < ListBox1.Items.Count; i++)
            {
                if (ListBox1.Items[i].Selected)
                {
                    if (!arraylist1.Contains(ListBox1.Items[i]))
                    {
                        arraylist1.Add(ListBox1.Items[i]);

                    }
                }
            }
            for (int i = 0; i < arraylist1.Count; i++)
            {
                if (!ListBox2.Items.Contains(((ListItem)arraylist1[i])))
                {
                    ListBox2.Items.Add(((ListItem)arraylist1[i]));
                }
                ListBox1.Items.Remove(((ListItem)arraylist1[i]));
            }
            ListBox2.SelectedIndex = -1;
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (ListBox2.SelectedIndex >= 0)
        {
            for (int i = 0; i < ListBox2.Items.Count; i++)
            {
                if (ListBox2.Items[i].Selected)
                {
                    if (!arraylist2.Contains(ListBox2.Items[i]))
                    {
                        arraylist2.Add(ListBox2.Items[i]);
                    }
                }
            }
            for (int i = 0; i < arraylist2.Count; i++)
            {
                if (!ListBox1.Items.Contains(((ListItem)arraylist2[i])))
                {
                    ListBox1.Items.Add(((ListItem)arraylist2[i]));
                }
                ListBox2.Items.Remove(((ListItem)arraylist2[i]));
            }
            ListBox1.SelectedIndex = -1;
        }   
    }
}