﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Xml;

public partial class insertfetchfromxml : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDataList();
        }
    }
    protected void BindDataList() 
    {
        XmlTextReader xmlreader = new XmlTextReader(Server.MapPath("az.xml"));
        DataSet ds = new DataSet();
        ds.ReadXml(xmlreader);
        xmlreader.Close();
        if (ds.Tables.Count != 0)
        {
            DataList1.DataSource = ds;
            DataList1.DataBind();
        }
        else 
        {
            DataList1.DataSource = null;
            DataList1.DataBind();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        XmlDocument xmldoc = new XmlDocument();
        xmldoc.Load(Server.MapPath("az.xml"));
        XmlElement parentelement = xmldoc.CreateElement("details");

        XmlElement name = xmldoc.CreateElement("name");
        name.InnerText = TextBox1.Text;
        XmlElement empid = xmldoc.CreateElement("empid");
        empid.InnerText = TextBox2.Text;
        XmlElement qulification = xmldoc.CreateElement("qulification");
        qulification.InnerText = DropDownList1.SelectedItem.Text;

        parentelement.AppendChild(name);
        parentelement.AppendChild(empid);
        parentelement.AppendChild(qulification);
        xmldoc.DocumentElement.AppendChild(parentelement);
        xmldoc.Save(Server.MapPath("az.xml"));
        BindDataList();
    }
}