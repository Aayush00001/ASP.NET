﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class repetear : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["aaConnectionString"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData();
        }
    }

    private void BindData()
    {
        SqlCommand cmd = new SqlCommand("Select * from aaa", con);
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        Repeater1.DataSource = reader;
        Repeater1.DataBind();
        con.Close();
    }
}