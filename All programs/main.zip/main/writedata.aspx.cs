﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class writedata : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["aaConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        ﻿con.Open();
        SqlDataAdapter sda = new SqlDataAdapter("select * from aaa",con);
        DataTable dt = new DataTable("aaa");
        sda.Fill(dt);
        dt.WriteXml(Server.MapPath("az.xml"));
        con.Close();

    }
}