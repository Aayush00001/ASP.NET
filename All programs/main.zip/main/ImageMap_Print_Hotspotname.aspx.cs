﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ImageMap_Print_Hotspotname : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ImageMap1_Click(object sender, ImageMapEventArgs e)
    {
        String str = e.PostBackValue;
        if (str == "Circle")
            Label1.Text = ImageMap1.HotSpots[0].ToString();
        if (str == "Rectangle")
            Label2.Text = ImageMap1.HotSpots[1].ToString();
        if (str == "polygon")
            Label3.Text = ImageMap1.HotSpots[2].ToString();         
    }
}