﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class datareader : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlCommand command = new SqlCommand("SELECT * FROM STD;", con);
        con.Open();
        SqlDataReader reader = command.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                //Label l = new Label();
                //l.Text = reader[0] + "\t" + reader[1].ToString() + "<br>";
                //form1.Controls.Add(1);

                Response.Write("<br>" + reader[0] + "\t" + reader[1]);
            }
        }
        else
        {
            Response.Write("no rows found");
        }
        reader.Close();
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}