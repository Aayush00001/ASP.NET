﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class exerciseprogram : System.Web.UI.Page
{
    string[] usStates = { "Alabama", "Alaska", "Georgia" };
    string[] AlabamaCities = { "Birmingham", "Montgomery", "Mobile", "Huntsville", "Tuscaloosa", "Hoover", "Dothan", "Auburn", "Decatur", "Madison" };

    string[] AlaskaCities = { "Anchorage", "Fairbanks", "Juneau", "Sitka", "Ketchikan", "Wasilla", "Kenai", "Kodiak", "Bethel", "Palmer" };

    string[] GeorgiaCities = { "Atlanta", "Augusta", "Columbus", "Savannah", "Athens", "SandySprings", "Macon", "Roswell", "Albany", "JohnsCreek" };


    string[] canadianProvinces = { "Alberta", "British Columbia", "Manitoba" };
    string[] AlbertaCities = { "Calgary", "Edmonton", "RedDeer", "Lethbridge", "St.Albert", "MedicineHat", "GrandePrairie", "Airdrie", "SpruceGrove", "Leduc" };

    string[] BritishColumbiaCities = { "Vancouver", "Surrey", "Burnaby", "Richmond", "Kelowna", "Abbotsford", "Coquitlam", "Langley", "Delta", "Saanich" };

    string[] ManitobaCities = { "Winnipeg", "Brandon", "Steinbach", "Thompson", "PortageLaPrairie", "Selkirk", "Winkler", "Dauphin", "Morden", "ThePas" };



    string[] australiaRegions = { "New South Wales", "Victoria", "Queensland" };
    string[] NewSouthWalesCities = { "Sydney", "Newcastle", "CentralCoast", "Wollongong", "Maitland", "TweedHeads", "Albury", "PortMacquarie", "Tamworth", "Orange" };

    string[] VictoriaCities = { "Melbourne", "Geelong", "Ballarat", "Bendigo", "Shepparton", "Melton", "Mildura", "Warrnambool", "Sunbury", "Pakenham" };

    string[] QueenslandCities = { "Brisbane", "GoldCoast", "SunshineCoast", "Townsville", "Cairns", "Toowoomba", "Mackay", "Rockhampton", "Bundaberg", "HerveyBay" };



    string[] germanStates = { "Baden-Württemberg", "Bavaria", "Berlin" };
    string[] BadenWurttembergCities = { "Stuttgart", "Karlsruhe", "Mannheim", "Freiburg", "Heidelberg", "Heilbronn", "Pforzheim", "Ulm", "Reutlingen", "Esslingen" };

    string[] BavariaCities = { "Munich", "Nuremberg", "Augsburg", "Regensburg", "Ingolstadt", "Wurzburg", "Furth", "Erlangen", "Bamberg", "Aschaffenburg" };

    string[] BerlinCities = { "Berlin" };



    string[] japanPrefectures = { "Hokkaido", "Aomori", "Iwate" };
    string[] HokkaidoCities = { "Sapporo", "Asahikawa", "Hakodate", "Kitami", "Obihiro", "Otaru", "Tomakomai", "Wakkanai", "Iwamizawa", "Abashiri" };

    string[] AomoriCities = { "Aomori", "Hirosaki", "Hachinohe", "Misawa", "Goshogawara", "Tsugaru", "Mutsu", "Towada", "Mutsu", "Towada" };

    string[] IwateCities = { "Morioka", "Oshu", "Hanamaki", "Kitakami", "Tono", "Kamaishi", "Ichinoseki", "Miyako", "Ninohe", "Kuji" };



    string[] brazilStates = { "Acre", "Alagoas", "Amapá" };
    string[] AcreCities = { "RioBranco", "CruzeirodoSul", "SenaMadureira", "Tarauacá", "Feijó", "SenadorGuiomard", "PlácidodeCastro", "Brasiléia", "PortoAcre", "MâncioLima" };

    string[] AlagoasCities = { "Maceió", "Arapiraca", "RioLargo", "PalmeiradosÍndios", "MarechalDeodoro", "Penedo", "DelmiroGouveia", "SãoMigueldosCampos", "CampoAlegre", "Santana doIpanema" };

    string[] AmapaCities = { "Macapá", "Santana", "Laranjal doJari", "Oiapoque", "Mazagão", "PortoGrande", "Tartarugalzinho", "PedraBranca doAmaparí", "Serra doNavio", "Cutias" };



    string[] indiaStates = { "Andhra Pradesh", "Gujarat", "Haryana" };
    string[] AndhraPradeshCities = { "Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Rajahmundry", "Tirupati", "Kakinada", "Kadapa", "Anantapur" };

    string[] GujaratCities = { "Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Gandhidham", "Nadiad" };

    string[] HaryanaCities = { "Faridabad", "Gurgaon", "Panipat", "Ambala", "Yamunanagar", "Rohtak", "Hisar", "Karnal", "Sonipat", "Panchkula" };



    string[] franceRegions = { "Auvergne-Rhône-Alpes", "Bourgogne-Franche-Comté", "Brittany" };
    string[] AuvergneRhoneAlpesCities = { "Lyon", "Saint-Etienne", "Grenoble", "Clermont-Ferrand", "Chambéry", "Annecy", "Valence", "Villeurbanne", "Vénissieux", "Roanne" };

    string[] BourgogneFrancheComteCities = { "Dijon", "Besançon", "Belfort", "Chalon-sur-Saône", "Mâcon", "Nevers", "Auxerre", "Montbéliard", "Sens", "Dole" };

    string[] BrittanyCities = { "Rennes", "Brest", "Quimper", "Lorient", "Vannes", "Saint-Malo", "Saint-Brieuc", "Lanester", "Fougères", "Concarneau" };



    string[] mexicoStates = { "Aguascalientes", "Baja California", "Baja California Sur" };
    string[] AguascalientesCities = { "Aguascalientes", "JesúsMaría", "PabellóndeArteaga", "RincóndeRomos", "Calvillo", "Asientos", "SanFranciscode losRomos", "Tepezalá", "ElLlano", "Cosío" };

    string[] BajaCaliforniaCities = { "Tijuana", "Mexicali", "Ensenada", "Rosarito", "Tecate" };

    string[] BajaCaliforniaSurCities = { "LaPaz", "SanJosédelCabo", "CaboSanLucas", "CiudadConstitución", "GuerreroNegro" };



    string[] southAfricaProvinces = { "Eastern Cape", "Free State", "Gauteng" };
    string[] EasternCapeCities = { "PortElizabeth", "EastLondon", "Uitenhage", "Mdantsane", "Grahamstown", "PortAlfred", "Queenstown", "Mthatha", "Cradock", "Bhisho" };

    string[] FreeStateCities = { "Bloemfontein", "Welkom", "Botshabelo", "Virginia", "Kroonstad", "Bethlehem", "Sasolburg", "Parys", "Phuthaditjhaba", "Harrismith" };

    string[] GautengCities = { "Johannesburg", "Pretoria", "Soweto", "Benoni", "Boksburg", "Centurion", "Germiston", "KemptonPark", "Springs", "Randburg" };



    string[] science_stream = { "Engineering", "Medical", "Biotechology" };
    string[] computer_science_stream = { "BTech", "BCA", "BscIT" };
    string[] commerce_stream = { "BBA", "BCOM", "CA" };
    string[] arts_stream = { "Journalism", "LLB", "Fine Arts [BFA]" };

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        switch (DropDownList2.SelectedValue)
        {
            case "Alabama":
                DropDownList2.DataSource = AlabamaCities;
                break;
            case "Alaska":
                DropDownList2.DataSource = AlaskaCities;
                break;
            case "Georgia":
                DropDownList2.DataSource = GeorgiaCities;
                break;
            case "Alberta":
                ddlCity.DataSource = AlbertaCities;
                DropDownList2;
            case "British Columbia":
                DropDownList2.DataSource = BritishColumbiaCities;
                break;
            case "Manitoba":
                DropDownList2.DataSource = ManitobaCities;
                break;
            case "New South Wales":
                DropDownList2.DataSource = NewSouthWalesCities;
                break;
            case "Victoria":
                DropDownList2.DataSource = VictoriaCities;
                break;
            case "Queensland":
                DropDownList2.DataSource = QueenslandCities;
                break;
            case "Baden-Württemberg":
                ddlCity.DataSource = BadenWurttembergCities;
                break;
            case "Bavaria":
                DropDownList2.DataSource = BavariaCities;
                break;
            case "Berlin":
                DropDownList2.DataSource = BerlinCities;
                break;
            case "Hokkaido":
                DropDownList2.DataSource = HokkaidoCities;
                break;
            case "Aomori":
                DropDownList2.DataSource = AomoriCities;
                break;
            case "Iwate":
                DropDownList2.DataSource = IwateCities;
                break;
            case "Acre":
                DropDownList2.DataSource = AcreCities;
                break;
            case "Alagoas":
                DropDownList2.DataSource = AlagoasCities;
                break;
            case "Amapá":
                DropDownList2.DataSource = AmapaCities;
                break;
            case "Andhra Pradesh":
                DropDownList2.DataSource = AndhraPradeshCities;
                break;
            case "Gujarat":
                DropDownList2.DataSource = GujaratCities;
                break;
            case "Haryana":
                DropDownList2.DataSource = HaryanaCities;
                break;
            case "Auvergne-Rhône-Alpes":
                DropDownList2.DataSource = AuvergneRhoneAlpesCities;
                break;
            case "Bourgogne-Franche-Comté":
                DropDownList2.DataSource = BourgogneFrancheComteCities;
                break;
            case "Brittany":
                DropDownList2.DataSource = BrittanyCities;
                break;
            case "Aguascalientes":
                DropDownList2.DataSource = AguascalientesCities;
                break;
            case "Baja California":
                DropDownList2.DataSource = BajaCaliforniaCities;
                break;
            case "Baja California Sur":
                DropDownList2.DataSource = BajaCaliforniaSurCities;
                break;
            case "Eastern Cape":
                DropDownList2.DataSource = EasternCapeCities;
                break;
            case "Free State":
                DropDownList2.DataSource = FreeStateCities;
                break;
            case "Gauteng":
                DropDownList2.DataSource = GautengCities;
                break;
            default:
                // Handle default case
                break;
        }
        DropDownList2.DataBind();


    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        // Populate the state dropdown based on the selected country
        switch (DropDownList1.SelectedValue)
        {
            case "United States":
                DropDownList1.DataSource = usStates;
                break;
            case "Canada":
                DropDownList1.DataSource = canadianProvinces;
                break;
            case "Australia":
                DropDownList1.DataSource = australiaRegions;
                break;
            case "Germany":
                DropDownList1.DataSource = germanStates;
                break;
            case "Japan":
                DropDownList1.DataSource = japanPrefectures;
                break;
            case "Brazil":
                DropDownList1.DataSource = brazilStates;
                break;
            case "India":
                DropDownList1.DataSource = indiaStates;
                break;
            case "France":
                ddlState.DataSource = franceRegions;
                break;
            case "Mexico":
                DropDownList1.DataSource = mexicoStates;
                break;
            case "South Africa":
                DropDownList1.DataSource = southAfricaProvinces;
                break;
            default:
                // Handle default case
                break;
        }

        // Bind the data to the state dropdown
        DropDownList1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //PanelIn.Visible = false;
        Label1.Visible = true;



        Label2.Text = TextBox1.Text;
        Lable5.Text = Calendar1.SelectedDate.ToShortDateString();
        Lable18.Text = DropDownList1.Text;
        Lable20.Text = Dr.Text;
        set_ct.Text = ddlCity.Text;
        string itm = "";
        int index = hby.Items.Count;
        for (int i = 0; i < index; i++)
        {
            if (hby.Items[i].Selected)
            {
                if (itm == "")
                    itm += hby.Items[i].Value.ToString();
                else
                    itm += " ," + hby.Items[i].Value.ToString();
            }
        }

        set_hby.Text = itm;
        if (male.Checked)
            set_gnd.Text = male.Text;
        if (female.Checked)
            set_gnd.Text = female.Text;

        set_facluty.Text = RadioButtonList1.Text;
        set_stream.Text = strm_in.Text;


        string strpath = Server.MapPath("Upload_img") + "\\" + pro_pic.FileName;
        string strpath2 = "~/Upload_img/" + pro_pic.FileName;
        pro_pic.SaveAs(strpath);
        set_pro_pic.ImageUrl = strpath2;
    }

    protected void Bdate_SelectionChanged(object sender, EventArgs e)
    {
        string[] countries = { "United States", "Canada", "Australia", "Germany", "Japan", "Brazil", "India", "France", "Mexico", "South Africa" };
        ddlCountry.DataSource = countries;
        ddlCountry.DataBind();
    }
    protected void nm_TextChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (RadioButtonList1.SelectedValue == "Science")
        {
            strm_in.DataSource = science_stream;
            strm_in.DataBind();
        }
        if (RadioButtonList1.SelectedValue == "Computer Science")
        {
            strm_in.DataSource = computer_science_stream;
            strm_in.DataBind();
        }
        if (RadioButtonList1.SelectedValue == "Commerce")
        {
            strm_in.DataSource = commerce_stream;
            strm_in.DataBind();
        }
        if (RadioButtonList1.SelectedValue == "Arts")
        {
            strm_in.DataSource = arts_stream;
            strm_in.DataBind();
        }

    }
   
}