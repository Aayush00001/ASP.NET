﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applicationstate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int c = 0;
        if (Application["visit"] != null) 
        {
            c = Convert.ToInt32(Application["visit"]);
        }
        c = c + 1;
        Application["visit"] = c;
        Label1.Text = "Total Visit Is:" + c.ToString();
    }
}