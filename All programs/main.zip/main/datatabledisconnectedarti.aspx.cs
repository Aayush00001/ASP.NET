﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class datatabledisconnectedarti : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\1. COLLAGE\SEM6\asp.net\main\App_Data\Database.mdf;Integrated Security=True;User Instance=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        String qry="select * from std";
        SqlDataAdapter da=new SqlDataAdapter(qry,con);
        DataTable dt=new DataTable();
        da.Fill(dt);
        GridView1.DataSource=dt;
        GridView1.DataBind();
        con.Close();
    }

protected void  Button2_Click(object sender, EventArgs e)
{
    con.Open();
    String qry="select * from std";
    SqlDataAdapter da1=new SqlDataAdapter(qry,con);
    String qry1="select * from movie";
    SqlDataAdapter da2=new SqlDataAdapter(qry,con);
    DataSet ds=new DataSet();
    da1.Fill(ds,"std");
    da2.Fill(ds,"movie");
    GridView2.DataSource=ds.Tables[0];
    GridView2.DataBind();
    GridView3.DataSource=ds.Tables[1];
    GridView3.DataBind();
    con.Close();
}
}