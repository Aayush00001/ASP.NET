﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class abc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SetLights("red");
            }
        }

        protected void timer1_Tick(object sender, EventArgs e)
        {
            if (redLight.Visible)
            {
                SetLights("green");
            }
            else if (yellowLight.Visible)
            {
                SetLights("red");
            }
            else if (greenLight.Visible)
            {
                SetLights("yellow");
            }
        }
        private void SetLights(string activeLight)
        {
            redLight.Visible = false;
            yellowLight.Visible = false;
            greenLight.Visible = false;

            switch (activeLight)
            {
                case "red":
                    redLight.Visible = true;
                    break;
                case "yellow":
                    yellowLight.Visible = true;
                    break;
                case "green":
                    greenLight.Visible = true;
                    break;
            }
        }
    }
