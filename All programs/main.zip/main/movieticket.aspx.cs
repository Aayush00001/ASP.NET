﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class movieticket : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\ASUS\Documents\m.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        SqlCommand command = new SqlCommand("SELECT Seatno FROM movie", con);
        con.Open();
        SqlDataReader reader = command.ExecuteReader();
        if (reader.HasRows)
        {
            while (reader.Read())
            {
                string val = reader.GetString(0);
                Response.Write(val);
                //val.Split(",");
            }
        }
        //string[] authorsList = authors.Split(", ");
    }
    protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        DropDownList2.Items.Clear();
        DropDownList2.Items.Add("10:30 AM");
        DropDownList2.Items.Add("01:45 PM");
        DropDownList2.Items.Add("05:05 PM");
        DropDownList2.Items.Add("07:00 PM");
        DropDownList2.Items.Add("10:15 PM");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        string s = "";
        int p = 0;
        int tot = 0;
        for (int i = 0; i < CheckBoxList1.Items.Count; i++)
        {
        if (CheckBoxList1.Items[i].Selected)
        {
            s += ",A" + CheckBoxList1.Items[i].Text;
            tot++;
            p += 100;
        }
    }
    for (int i = 0; i < CheckBoxList2.Items.Count; i++)
    {
        if (CheckBoxList2.Items[i].Selected)
        {
            s += ",B" + CheckBoxList2.Items[i].Text;
            tot++;
            p += 100;
        }
    }
    for (int i = 0; i < CheckBoxList3.Items.Count; i++)
    {
        if (CheckBoxList3.Items[i].Selected)
        {
            s += ",C" + CheckBoxList3.Items[i].Text;
            tot++;
            p += 100;
        }
    }
    for (int i = 0; i < CheckBoxList4.Items.Count; i++)
    {
        if (CheckBoxList4.Items[i].Selected)
        {
            s += ",D" + CheckBoxList4.Items[i].Text;
            tot++;
            p += 100;
        }
    }
    int selseat = Int32.Parse(DropDownList3.SelectedValue.ToString());
    Response.Write("Total Seat: "+tot);
    Response.Write("<br>Seat is: "+selseat);
    if (tot >=selseat)
    {
        Label12.Text = "Multiple Seat Selected...";
    }
    else if (tot <= selseat)
    {
        Label12.Text = "Please select proper seat...";
    }
    else
    {
        string qry = "INSERT INTO movie (Name, Movienm, [Date], [Time], [Total seat], Seatno, Price) VALUES (@Name, @MovieName, @Date, @Time, @TotalSeat, @SeatNo, @Price)";

        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.Parameters.AddWithValue("@Name", TextBox1.Text); // Use TextBox1.Text instead of nm.Text
        cmd.Parameters.AddWithValue("@MovieName", DropDownList1.SelectedValue); // Assuming DropDownList1 contains movie names
        cmd.Parameters.AddWithValue("@Date", TextBox2.Text); // Use TextBox2.Text for date
        cmd.Parameters.AddWithValue("@Time", DropDownList2.SelectedValue);
        cmd.Parameters.AddWithValue("@TotalSeat", tot);
        cmd.Parameters.AddWithValue("@SeatNo", s);
        cmd.Parameters.AddWithValue("@Price", p);

        cmd.ExecuteNonQuery();

        Response.Write("Booking Successful!");
    }
    }
  
}
