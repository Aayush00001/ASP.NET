﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class insertintable : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\1. COLLAGE\SEM6\asp.net\main\App_Data\Database.mdf;Integrated Security=True;User Instance=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        con.Open();
        String qry="insert into std values("+TextBox1.Text+",'"+TextBox2.Text+"')";
        SqlCommand cmd = new SqlCommand(qry,con);
        if (cmd.ExecuteNonQuery() > 0)
        {
            Response.Write("inserted!!!!!");
            GridView1.DataBind();
        }
        else
            Response.Write("not inserted!!");
        con.Close();   
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        String qry = "update std set name='" + TextBox2.Text + "'where id=" + TextBox1.Text;
        SqlCommand cmd = new SqlCommand(qry, con);
        if (cmd.ExecuteNonQuery() > 0)
        {
            Response.Write("updated!!!!!");
            GridView1.DataBind();
        }
        else
            Response.Write("not updated!!");
        con.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        String qry = "delete from std where id=" + TextBox1.Text;
        SqlCommand cmd = new SqlCommand(qry, con);
        if (cmd.ExecuteNonQuery() > 0)
        {
            Response.Write("deleted!!!!!");
            GridView1.DataBind();
        }
        else
            Response.Write("not deleted!!");
        con.Close();
    }
}