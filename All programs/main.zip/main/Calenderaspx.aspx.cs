﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Calenderaspx : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        //date & time
        Label1.Text = Calendar1.SelectedDate.ToString();
        //date
        Label2.Text = Calendar1.SelectedDate.ToShortDateString();
        //date format
        Label3.Text =Calendar1.SelectedDate.ToString("dd-mm-yyyy");
    }
}