﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Indiamap : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }
    protected void ImageMap1_Click(object sender, ImageMapEventArgs e)
    {
        string region = e.PostBackValue;

        if (region == "gujarat")
        {
            regionMapView.ImageUrl = "~/images/Gujarat.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "maharashtra")
        {
            regionMapView.ImageUrl = "~/images/maharashtra.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "uttarPradesh")
        {
            regionMapView.ImageUrl = "~/images/UttarPradesh.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "chhattisgarh")
        {
            regionMapView.ImageUrl = "~/images/chhattisgarh.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "Odisha-map")
        {
            regionMapView.ImageUrl = "~/images/Odisha-map.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "bihar")
        {
            regionMapView.ImageUrl = "~/images/bihar.jpg";
            regionMapView.Visible = true;
        }






        else if (region == "rajasthan")
        {
            regionMapView.ImageUrl = "~/images/rajasthan.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "punjab")
        {
            regionMapView.ImageUrl = "~/images/punjab.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "haryana")
        {
            regionMapView.ImageUrl = "~/images/haryana.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "madhyaPradesh")
        {
            regionMapView.ImageUrl = "~/images/madhyaPradesh.jpg";
            regionMapView.Visible = true;
        }        


        






        else if (region == "goa")
        {
            regionMapView.ImageUrl = "~/images/goa.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "karnataka")
        {
            regionMapView.ImageUrl = "~/images/karnataka.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "kerala")
        {
            regionMapView.ImageUrl = "~/images/kerala.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "tamilnadu")
        {
            regionMapView.ImageUrl = "~/images/tamilnadu.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "andhra pradesh")
        {
            regionMapView.ImageUrl = "~/images/andhra pradesh.jpg";
            regionMapView.Visible = true;
        }        
        else if (region == "jharkhand")
        {
            regionMapView.ImageUrl = "~/images/jharkhand.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "westbengal")
        {
            regionMapView.ImageUrl = "~/images/westbengal.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "jammu_kashmir")
        {
            regionMapView.ImageUrl = "~/images/jammu_kashmir.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "himachal")
        {
            regionMapView.ImageUrl = "~/images/himachal.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "uttarakhand")
        {
            regionMapView.ImageUrl = "~/images/uttarakhand.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "nepal")
        {
            regionMapView.ImageUrl = "~/images/nepal.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "sikkim")
        {
            regionMapView.ImageUrl = "~/images/sikkim.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "bhutan")
        {
            regionMapView.ImageUrl = "~/images/bhutan.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "arunachal pradesh")
        {
            regionMapView.ImageUrl = "~/images/arunachal pradesh.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "assam")
        {
            regionMapView.ImageUrl = "~/images/assam.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "nagaland")
        {
            regionMapView.ImageUrl = "~/images/nagaland.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "meghalaya")
        {
            regionMapView.ImageUrl = "~/images/meghalaya.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "manipur")
        {
            regionMapView.ImageUrl = "~/images/manipur.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "mizoram")
        {
            regionMapView.ImageUrl = "~/images/mizoram.jpg";
            regionMapView.Visible = true;
        }
        else if (region == "tripura")
        {
            regionMapView.ImageUrl = "~/images/tripura.jpg";
            regionMapView.Visible = true;
        }          
    }
}